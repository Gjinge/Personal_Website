using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameOver : MonoBehaviour
{
    public TextMeshProUGUI finalScoreText;
    public TextMeshProUGUI highScoreText;
    public TextMeshProUGUI newRecordText;

    void Start()
    {
        int finalScore = PlayerPrefs.GetInt("FinalScore", 0);
        finalScoreText.text = ": " + finalScore;

        int highScore = PlayerPrefs.GetInt("HighScore", 0);

        if (finalScore == highScore)
        {
            PlayerPrefs.SetInt("HighScore", finalScore);
            PlayerPrefs.Save();
            highScoreText.text = "�¼�¼����߷�: " + finalScore;
            newRecordText.text = "��ϲ��������˼�¼��";
        }
        else
        {
            highScoreText.text = "��߷�: " + highScore;
            newRecordText.text = "";
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene("_Scene_0");
    }

    public void BackToMenu()
    {
        SceneManager.LoadScene("_StartScene");
    }

    public void ClearHighScore()
    {
        PlayerPrefs.DeleteKey("HighScore");
        highScoreText.text = "��߷�: 0";
        newRecordText.text = "";
    }
}
