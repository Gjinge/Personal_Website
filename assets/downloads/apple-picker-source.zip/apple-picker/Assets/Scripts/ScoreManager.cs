using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public static int currentScore = 0; // ������Ϸ�÷�

    public static void AddScore(int points)
    {
        currentScore += points;
    }

    public static void ResetScore()
    {
        currentScore = 0;
    }
}
